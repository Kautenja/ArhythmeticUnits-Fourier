// Host-independent correctness and negative checks for synthesis benchmarks.
// Copyright 2026 Arhythmetic Units
// SPDX-License-Identifier: GPL-3.0-or-later
#include "../../benchmark/paper/synthesis.hpp"
#include <limits>

template<typename Operation>
void rejects(Operation operation) {
    bool rejected = false;
    try { operation(); } catch (const std::runtime_error&) { rejected = true; }
    Paper::require(rejected, "A deliberately incorrect synthesis result was accepted");
}

template<typename T>
void fixtures() {
    using namespace Paper;
    for (const std::string family : {"ols-identity", "ols-fir"})
        for (const std::string mode : {"batch", "incremental"})
            for (size_t hop : {37u, 64u, 126u})
                for (size_t fixture = 0; fixture < 4; ++fixture) {
                    Config c{};
                    c.n = 128; c.hop = hop; c.backend = family+"-"+mode+"-float";
                    FrequencyChain<T> adapter(c);
                    std::vector<float> input(1024, 0);
                    if (fixture == 1) input[hop-1] = 1;
                    if (fixture == 2) std::fill(input.begin(), input.end(), 0.25f);
                    if (fixture == 3) input = signal();
                    SynthesisAccuracy accuracy;
                    SynthesisAudit audit{accuracy};
                    for (size_t sample = 0; sample < 3*input.size(); ++sample) {
                        adapter.process(input[sample%input.size()]);
                        audit(adapter, input, sample);
                    }
                    require(accuracy.publications > 0, "No fixture outputs checked");
                }
}

/// @brief Corrupt inverse/forward recovery must not disappear in a max reduction.
template<typename T>
void nonfinite_roundtrip() {
    using namespace Paper;
    require(Reference::absolute_error({3, 4}, {0, 0}) == 5, "Finite roundtrip error differs");
    for (const T value : {std::numeric_limits<T>::quiet_NaN(), std::numeric_limits<T>::infinity()}) {
        for (const std::complex<T> actual : {std::complex<T>(value, 0), std::complex<T>(0, value)}) {
            rejects([&]() {
                const auto error = std::max(0.L, Reference::absolute_error(Reference::Complex(actual), {0, 0}));
                require(error < Reference::tolerance<T>(), "Roundtrip tolerance exceeded");
            });
        }
    }
}

int main() {
    using namespace Paper;
    try {
        verify_synthesis<float>();
        verify_synthesis<double>();
        fixtures<float>();
        fixtures<double>();
        nonfinite_roundtrip<float>();
        nonfinite_roundtrip<double>();
        // A direct-sum oracle must reject scale, layout and missing-output errors.
        std::vector<Reference::Complex> expected = {Reference::Complex(1, 2), Reference::Complex(-3, 4)};
        std::vector<std::complex<double>> actual(expected.begin(), expected.end());
        Reference::compare<double>(actual, expected);
        std::swap(actual[0], actual[1]);
        rejects([&]() { Reference::compare<double>(actual, expected); });
        actual.assign(expected.begin(), expected.end());
        actual[0] *= 128.;
        rejects([&]() { Reference::compare<double>(actual, expected); });
        actual.pop_back();
        rejects([&]() { Reference::compare<double>(actual, expected); });
        Config c{};
        c.n = 128; c.hop = 32; c.backend = "inverse-stream-batch-float";
        InverseStream<float> inverse(c);
        inverse.process(0);
        SynthesisAccuracy accuracy;
        SynthesisAudit audit{accuracy};
        const auto input = signal();
        audit(inverse, input, 0);
        inverse.output[1] *= 128.f;
        rejects([&]() { audit(inverse, input, 0); });
        c.backend = "ols-fir-batch-float";
        FrequencyChain<float> chain(c);
        chain.process(input[0]);
        chain.playing.back() += std::complex<float>(1, 0);
        rejects([&]() { audit(chain, input, 0); });
        c.hop = c.n-1;
        rejects([&]() { FrequencyChain<float> invalid(c); });
        std::cout << "Synthesis baselines passed: both precisions, batch/incremental, "
            << "analytical inverse, direct FIR/identity, startup, wraparound, "
            << "non-dividing hops, output boundaries, and negative checks\n";
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
