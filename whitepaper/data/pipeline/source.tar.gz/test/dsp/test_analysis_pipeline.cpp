// Regression tests for the experimental complete analysis pipeline.
// Copyright 2026 Arhythmetic Units
// SPDX-License-Identifier: GPL-3.0-or-later
#include <atomic>
#include <cstdlib>
#include <new>
#include <thread>
#include "../../whitepaper/experiments/pipeline/legacy.hpp"
#define CATCH_CONFIG_MAIN
#include "catch.hpp"

namespace {
bool tracking = false;
size_t allocations = 0;
using Fourier::Experiment::Configuration;
using Fourier::Experiment::Pipeline;

/// @brief Repeatable input with nonstationary content, not a repeated frame.
float signal(size_t i, int fixture) {
    switch (fixture) {
    case 0: return 0;
    case 1: return i == 0 || i == 71 ? 1.f : 0.f;
    case 2: return 1.f;
    case 3: return i % 2 ? -1.f : 1.f;
    case 4: return std::sin(0.17f * i) + 0.25f * std::cos(0.61f * i);
    default: return float((uint32_t(i) * 1664525u + 1013904223u) >> 8) / 8388608.f - 1.f;
    }
}
}
void* operator new(size_t size) {
    if (tracking) ++allocations;
    if (void* result = std::malloc(size ? size : 1)) return result;
    throw std::bad_alloc();
}
void* operator new[](size_t size) { return ::operator new(size); }
void operator delete(void* value) noexcept { std::free(value); }
void operator delete[](void* value) noexcept { std::free(value); }

TEST_CASE("Pipeline validates preparation inputs") {
    CHECK_THROWS_AS(Configuration(3, 1, std::vector<float>(3)), std::invalid_argument);
    CHECK_THROWS_AS(Configuration(8, 0, std::vector<float>(8)), std::invalid_argument);
    CHECK_THROWS_AS(Configuration(8, 1, {}), std::invalid_argument);
    CHECK_THROWS_AS(Configuration(8, 1, std::vector<float>(8), -1), std::invalid_argument);
    CHECK_THROWS_AS(Configuration(8, 1, std::vector<float>(8), 0, 2), std::invalid_argument);
    CHECK_THROWS_AS(Configuration(8, 1, std::vector<float>(8), 0, 0, 0), std::invalid_argument);
    CHECK_THROWS_AS(Configuration(8, 1, std::vector<float>(8, NAN)), std::invalid_argument);
}

TEST_CASE("Pipeline preserves frames, cadence, stage budgets, and magnitudes") {
    for (size_t n : {4u, 16u, 128u, 1024u, 16384u}) {
        for (size_t hop : {size_t(1), n / 4, n / 2 + 1, n + 7}) {
            for (float octave : {0.f, 1.f / 3.f, 1.f}) {
                // Large cases use noise; small cases cover all named fixtures.
                for (int fixture = n > 128 ? 5 : 0; fixture < 6; ++fixture) {
                    CAPTURE(n, hop, octave, fixture);
                    std::vector<float> window(n, 1.f);
                    if (fixture % 2)
                        for (size_t i = 0; i < n; ++i)
                            window[i] = 1.f - std::cos(2.f * 3.14159265358979323846f * i / n);
                    Configuration config(n, hop, window, 0.8f, octave);
                    Pipeline pipeline(config), burst(config, Fourier::Experiment::Schedule::StageBurst);
                    Pipeline serial(config, Fourier::Experiment::Schedule::Serial);
                    std::vector<std::vector<float>> serial_results;
                    Fourier::OnTheFlyRFFT<float> reference(n);
                    std::vector<float> input(n), average(n / 2 + 1, 0.f);
                    size_t b = reference.get_total_steps(), count = 0;
                    const std::array<size_t, 4> work{{n/2, b, n/2+1, n/2+1}};
                    for (size_t t = 0; t < 12 * hop; ++t) {
                        const bool ready = pipeline.process(signal(t, fixture));
                        if (serial.process(signal(t, fixture)))
                            serial_results.push_back(serial.mailbox.consume()->magnitude);
                        REQUIRE(burst.process(signal(t, fixture)) == ready);
                        REQUIRE(ready == (t >= 4*hop-1 && (t+1) % hop == 0));
                        const size_t phase = t % hop;
                        for (size_t stage = 0; stage < 4; ++stage) {
                            const size_t expected = t / hop < stage ? 0
                                : (phase+1)*work[stage]/hop - phase*work[stage]/hop;
                            REQUIRE(pipeline.last_work[stage] == expected);
                        }
                        if (!ready) continue;
                        const auto* result = pipeline.mailbox.consume();
                        const auto* other = burst.mailbox.consume();
                        REQUIRE(result != nullptr);
                        REQUIRE(other != nullptr);
                        REQUIRE(result->frame_end == count * hop);
                        REQUIRE(result->magnitude == other->magnitude);
                        REQUIRE(result->magnitude == serial_results.at(count));
                        for (size_t i = 0; i < n; ++i) {
                            const int64_t index = int64_t(result->frame_end) - int64_t(n) + 1 + i;
                            input[i] = index < 0 ? 0.f : signal(size_t(index), fixture);
                        }
                        reference.buffer(input.data(), window);
                        reference.compute();
                        if (octave > 0) reference.smooth(48000.f, octave);
                        for (size_t k = 0; k <= n/2; ++k) {
                            average[k] = 0.8f * std::abs(average[k])
                                + (1.f-0.8f) * std::abs(reference.coefficients[k]);
                            REQUIRE(result->magnitude[k] == Approx(average[k]).margin(1e-5f));
                        }
                        ++count;
                    }
                    REQUIRE(count == 9);
                }
            }
        }
    }
}

TEST_CASE("Pipeline agrees with an independent direct DFT") {
    const size_t n = 32, hop = 7;
    Configuration config(n, hop, std::vector<float>(n, 1.f), 0.f, 0.f);
    Pipeline pipeline(config);
    for (size_t t = 0; t < 160; ++t) {
        if (!pipeline.process(signal(t, 4))) continue;
        const auto* result = pipeline.mailbox.consume();
        for (size_t k = 0; k <= n/2; ++k) {
            std::complex<double> expected(0, 0);
            for (size_t i = 0; i < n; ++i) {
                const int64_t index = int64_t(result->frame_end) - int64_t(n) + 1 + i;
                const double angle = -2 * std::acos(-1.) * k * i / n;
                const double value = index < 0 ? 0. : signal(size_t(index), 4);
                expected += value * std::complex<double>(std::cos(angle), std::sin(angle));
            }
            REQUIRE(result->magnitude[k] == Approx(std::abs(expected)).margin(2e-5));
        }
    }
}

TEST_CASE("Processing and publication allocate nothing with a stalled consumer") {
    Configuration config(1024, 257, std::vector<float>(1024, 1.f));
    Pipeline pipeline(config);
    allocations = 0;
    tracking = true;
    for (size_t i = 0; i < 10000; ++i) pipeline.process(float(i % 13));
    tracking = false;
    CHECK(allocations == 0);
    const auto* held = pipeline.mailbox.consume();
    REQUIRE(held != nullptr);
    const auto copy = held->magnitude;
    const auto end = held->frame_end;
    tracking = true;
    for (size_t i = 0; i < 10000; ++i) pipeline.process(0.f);
    tracking = false;
    CHECK(allocations == 0);
    CHECK(held->frame_end == end);
    CHECK(held->magnitude == copy);
    REQUIRE(pipeline.mailbox.consume() != nullptr);
    CHECK(pipeline.mailbox.current().frame_end > end);
}

TEST_CASE("Concurrent consumer sees only complete immutable snapshots") {
    Configuration config(64, 17, std::vector<float>(64, 1.f), 0.f, 0.f);
    Pipeline pipeline(config);
    std::atomic<bool> finished{false};
    std::atomic<size_t> failures{0}, consumed{0};
    std::thread consumer([&] {
        uint64_t previous = 0;
        do {
            if (const auto* frame = pipeline.mailbox.consume()) {
                if (frame->frame_end < previous || frame->frame_end % 17) ++failures;
                previous = frame->frame_end;
                if (frame->frame_end >= 63) {
                    if (std::abs(frame->magnitude[0] - 64.f) > 1e-5f) ++failures;
                    for (size_t k = 1; k <= 32; ++k)
                        if (frame->magnitude[k] != 0.f) ++failures;
                }
                ++consumed;
            }
        } while (!finished.load());
    });
    for (size_t i = 0; i < 200000; ++i) pipeline.process(1.f);
    finished = true;
    consumer.join();
    CHECK(failures == 0);
    CHECK(consumed > 0);
}

TEST_CASE("Fixed-cadence legacy adapter and pipeline publish the same sequence") {
    for (float rate : {44100.f, 48000.f, 96000.f}) {
        for (float octave : {0.f, 1.f / 6.f, 1.f}) {
            const size_t n = 128, hop = 37;
            Configuration config(n, hop, std::vector<float>(n, 1.f), 0.3f, octave, rate);
            Pipeline pipeline(config);
            Pipeline serial(config, Fourier::Experiment::Schedule::Serial);
            Fourier::Experiment::Legacy legacy(config);
            std::vector<std::vector<float>> expected;
            for (size_t t = 0; t < 20 * hop; ++t) {
                const bool ready = legacy.process(signal(t, 5));
                REQUIRE(serial.process(signal(t, 5)) == ready);
                const size_t total = n/2 + (n/4)*6 + 2*(n/2+1);
                size_t used = 0;
                for (size_t value : serial.last_work) used += value;
                REQUIRE(used == ((t%hop+1)*total/hop - (t%hop)*total/hop));
                if (ready) {
                    expected.push_back(legacy.mailbox.consume()->magnitude);
                    const auto* frame = serial.mailbox.consume();
                    REQUIRE(frame->frame_end == t+1-hop);
                    for (size_t k = 0; k < frame->magnitude.size(); ++k)
                        REQUIRE(frame->magnitude[k] == Approx(expected.back()[k]).margin(1e-5f));
                }
                if (pipeline.process(signal(t, 5))) {
                    const auto* frame = pipeline.mailbox.consume();
                    const auto& reference = expected.at(frame->frame_end / hop);
                    for (size_t k = 0; k < reference.size(); ++k)
                        REQUIRE(frame->magnitude[k] == Approx(reference[k]).margin(1e-5f));
                }
            }
        }
    }
}

TEST_CASE("Serial scheduling allocates nothing after preparation") {
    Configuration config(1024, 257, std::vector<float>(1024, 1.f));
    Pipeline pipeline(config, Fourier::Experiment::Schedule::Serial);
    allocations = 0;
    tracking = true;
    for (size_t i = 0; i < 10000; ++i) pipeline.process(float(i % 13));
    tracking = false;
    CHECK(allocations == 0);
}
