// Fixed-cadence adapter around the shipping scalar RFFT for controlled timing.
// Copyright 2026 Arhythmetic Units
// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef ARHYTHMETIC_UNITS_FOURIER_EXPERIMENTAL_LEGACY_HPP_
#define ARHYTHMETIC_UNITS_FOURIER_EXPERIMENTAL_LEGACY_HPP_
#include "pipeline.hpp"
#include "dsp/circular_buffer.hpp"
namespace Fourier {
namespace Experiment {

/// @brief Current arithmetic with exact frame starts and snapshot publication.
/// @details Output publishes at frame_end+H-1; reconstruction still occurs on
/// the last effective butterfly call, which may precede the hop's end.
/// This adapter isolates cadence from the production restart-on-completion
/// policy. The mailbox is safe in both modes; this is not the Rack module.
class Legacy {
    Configuration config;
    OnTheFlyRFFT<float> fft;
    ContiguousCircularBuffer<float> ring;
    std::vector<float> filtered;
    size_t phase = 0;
    uint64_t sample_index = 0;
 public:
    DisplayMailbox<Spectrum> mailbox;
    explicit Legacy(const Configuration& c) : config(c), fft(c.n), ring(c.n),
        filtered(c.n, 0.f) { prepare_mailbox(mailbox, c.n / 2 + 1); }
    bool process(float input) {
        ring.insert(input);
        if (phase == 0) fft.buffer(ring.contiguous(), config.window);
        fft.step(config.hop);
        ++sample_index;
        if (++phase != config.hop) return false;
        phase = 0;
        if (config.octave > 0) fft.smooth(config.sample_rate, config.octave);
        for (size_t k = 0; k < config.n; ++k)
            filtered[k] = config.alpha * std::abs(filtered[k])
                + (1.f - config.alpha) * std::abs(fft.coefficients[k]);
        auto& result = mailbox.writable();
        std::copy(filtered.begin(), filtered.begin() + result.magnitude.size(),
                  result.magnitude.begin());
        result.frame_end = sample_index - config.hop;
        mailbox.publish();
        return true;
    }
};
}  // namespace Experiment
}  // namespace Fourier
#endif  // ARHYTHMETIC_UNITS_FOURIER_EXPERIMENTAL_LEGACY_HPP_
