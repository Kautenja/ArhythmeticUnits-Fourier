// Phase costs of the existing scalar analysis path (fixed cadence harness).
// Copyright 2026 Arhythmetic Units
// SPDX-License-Identifier: GPL-3.0-or-later
#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <vector>
#include "dsp/fft.hpp"
#include "dsp/circular_buffer.hpp"
using Clock = std::chrono::steady_clock;
volatile double sink = 0;
int main() {
    std::cout << "n,hop,repetition,buffer_ns,reconstruct_ns,post_ns\n";
    for (size_t n : {1024u, 4096u, 16384u}) {
        const size_t hop = n / 4;
        Fourier::OnTheFlyRFFT<float> fft(n);
        Fourier::ContiguousCircularBuffer<float> ring(n);
        std::vector<float> window(n), filtered(n, 0.f), output(n / 2 + 1);
        for (size_t i = 0; i < n; ++i) {
            ring.insert(std::sin(float(i) * 0.07f));
            window[i] = 1.f - std::cos(2.f * 3.14159265358979323846f * i / n);
        }
        for (size_t repetition = 0; repetition < 9; ++repetition) {
            double buffer = 0, finish = 0, post = 0;
            for (size_t frame = 0; frame < 80; ++frame) {
                const auto a = Clock::now();
                fft.buffer(ring.contiguous(), window);
                const auto b = Clock::now();
                for (size_t j = 1; j < fft.get_total_steps(); ++j) fft.step();
                const auto c = Clock::now();
                fft.step();
                const auto d = Clock::now();
                fft.smooth(48000.f, 1.f / 3.f);
                for (size_t k = 0; k < n; ++k)
                    filtered[k] = 0.8f * std::abs(filtered[k])
                        + 0.2f * std::abs(fft.coefficients[k]);
                std::copy(filtered.begin(), filtered.begin() + output.size(), output.begin());
                const auto e = Clock::now();
                if (frame >= 16) {
                    buffer += std::chrono::duration<double, std::nano>(b-a).count();
                    finish += std::chrono::duration<double, std::nano>(d-c).count();
                    post += std::chrono::duration<double, std::nano>(e-d).count();
                }
                for (float v : output) sink += v;
            }
            std::cout << n << ',' << hop << ',' << repetition << ','
                      << buffer / 64 << ',' << finish / 64 << ',' << post / 64 << '\n';
        }
    }
}
