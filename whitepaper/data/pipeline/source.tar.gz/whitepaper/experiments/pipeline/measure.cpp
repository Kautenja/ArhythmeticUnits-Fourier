// Complete scalar pipeline comparison and matched stage-burst ablation.
// Copyright 2026 Arhythmetic Units
// SPDX-License-Identifier: GPL-3.0-or-later
#include <chrono>
#include <iomanip>
#include <iostream>
#include <string>
#include "legacy.hpp"
using Clock = std::chrono::steady_clock;
using Fourier::Experiment::Configuration;
using Fourier::Experiment::Pipeline;
using Fourier::Experiment::Legacy;
namespace {
volatile double checksum = 0;
double ns(Clock::time_point a, Clock::time_point b) {
    return std::chrono::duration<double, std::nano>(b-a).count();
}
/// @brief Consume every output value outside timed processing regions.
template<typename Processor>
void consume(Processor& processor) {
    if (const auto* result = processor.mailbox.consume())
        for (float value : result->magnitude) checksum += value;
}
/// @brief Identical deterministic input for each mode and repetition.
std::vector<float> signal(size_t length) {
    std::vector<float> input(length);
    uint32_t state = 12345678;
    for (auto& sample : input) {
        state = state * 1664525u + 1013904223u;
        sample = float(state >> 8) / 8388608.f - 1.f;
    }
    return input;
}
/// @brief Warm the same number of hops; extra pipeline latency is drained.
template<typename Processor>
void warm(Processor& processor, const std::vector<float>& input, size_t hop) {
    for (size_t i = 0; i < 20 * hop; ++i) {
        processor.process(input[i % input.size()]);
        if ((i+1) % hop == 0) consume(processor);
    }
}
/// @brief One pass measures throughput per hop, samples, or simulated blocks.
/// @details No timer per sample in the throughput/block passes. Per-sample
/// observations include timer overhead. Each pass starts from fresh state.
template<typename Processor>
void pass(Processor& processor, const Configuration& c, const char* mode,
          size_t repetition, size_t block) {
    const size_t frames = 64;
    const auto input = signal(frames * c.hop);
    warm(processor, input, c.hop);
    std::vector<double> times;
    const size_t width = block == 0 ? c.hop : block;
    const size_t count = frames * c.hop;
    times.reserve(count / width + 1);
    size_t publications = 0;
    for (size_t start = 0; start < count; start += width) {
        const auto a = Clock::now();
        for (size_t i = start; i < std::min(count, start + width); ++i)
            publications += processor.process(input[i]);
        const auto b = Clock::now();
        times.push_back(ns(a, b));
        consume(processor);
    }
    if (publications != frames) throw std::runtime_error("Wrong steady-state cadence");
    double total = 0;
    for (double value : times) total += value;
    std::sort(times.begin(), times.end());
    const auto quantile = [&](double p) {
        return times[static_cast<size_t>(std::ceil(p * times.size()))-1];
    };
    std::cout << c.n << ',' << c.hop << ',' << c.octave << ',' << repetition << ','
        << mode << ',' << block << ',' << times.size() << ',' << total / frames << ','
        << quantile(0.5) << ',' << quantile(0.99) << ',' << times.back() << ','
        << ((std::string(mode) == "legacy" || std::string(mode) == "serial") ? c.hop-1 : 4*c.hop-1) << '\n';
}
}
int main(int argc, char** argv) {
    std::cout << std::setprecision(12);
    if (argc > 1 && std::string(argv[1]) == "clock") {
        std::vector<double> values(10000);
        for (auto& value : values) {
            const auto a = Clock::now(), b = Clock::now();
            value = ns(a, b);
        }
        std::sort(values.begin(), values.end());
        std::cout << "{\"empty_timer_median_ns\":" << values[4999]
                  << ",\"empty_timer_p99_ns\":" << values[9899] << "}\n";
        return 0;
    }
    std::cout << "n,hop,octave,repetition,mode,block,observations,hop_ns,median_ns,p99_ns,max_ns,age_samples\n";
    for (size_t repetition = 0; repetition < 12; ++repetition)
        for (size_t n : {1024u, 4096u, 16384u})
            for (size_t hop : {n/4, n/2})
                for (float octave : {0.f, 1.f/3.f}) {
                    std::vector<float> window(n);
                    for (size_t i = 0; i < n; ++i)
                        window[i] = 1.f - std::cos(2.f * 3.14159265358979323846f * i/n);
                    Configuration c(n, hop, window, 0.8f, octave);
                    // Rotate order so mode positions; twelve repeats give balanced order.
                    for (size_t order = 0; order < 4; ++order)
                        for (size_t block : {0u, 1u, 16u, 64u, 256u}) {
                            switch ((order + repetition) % 4) {
                            case 0: {
                                Legacy processor(c);
                                pass(processor, c, "legacy", repetition, block);
                                break;
                            }
                            case 1: {
                                Pipeline processor(c, Fourier::Experiment::Schedule::StageBurst);
                                pass(processor, c, "stage_burst", repetition, block);
                                break;
                            }
                            case 3: {
                                Pipeline processor(c, Fourier::Experiment::Schedule::Serial);
                                pass(processor, c, "serial", repetition, block);
                                break;
                            }
                            case 2: {
                                Pipeline processor(c);
                                pass(processor, c, "pipeline", repetition, block);
                                break;
                            }
                            }
                        }
                }
}
