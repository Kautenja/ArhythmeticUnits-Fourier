// Experimental four-stage scalar spectrum pipeline; not used by Rack modules.
// Copyright 2026 Arhythmetic Units
// SPDX-License-Identifier: GPL-3.0-or-later
#ifndef ARHYTHMETIC_UNITS_FOURIER_EXPERIMENTAL_PIPELINE_HPP_
#define ARHYTHMETIC_UNITS_FOURIER_EXPERIMENTAL_PIPELINE_HPP_

#include <algorithm>
#include <array>
#include <cmath>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <vector>
#include <utility>
#include "dsp/fft.hpp"
#include "rack_extensions/display_mailbox.hpp"

namespace Fourier {
namespace Experiment {

/// @brief Positive magnitudes and the input sample index ending their frame.
/// @details Consumer storage is immutable until its next successful consume.
struct Spectrum {
    std::vector<float> magnitude;
    uint64_t frame_end = 0;
};

/// @brief Fixed configuration, constructed off the processing thread.
/// @details Bounds intentionally match a small experimental domain. Windows
/// must contain N finite values; normalization is supplied by the caller.
struct Configuration {
    const size_t n, hop;
    const std::vector<float> window;
    const float alpha, octave, sample_rate;
    Configuration(size_t length, size_t horizon, std::vector<float> weights,
                  float averaging = 0.8f, float smoothing = 1.f / 3.f,
                  float rate = 48000.f) :
        n(length), hop(horizon), window(std::move(weights)),
        alpha(averaging), octave(smoothing), sample_rate(rate) {
        if (n < 4 || n > 16384 || (n & (n - 1)) || !hop || hop > 65536
            || window.size() != n || !std::isfinite(alpha) || alpha < 0
            || alpha > 1 || !std::isfinite(octave) || octave < 0 || octave > 1
            || !std::isfinite(sample_rate) || sample_rate < 1 || sample_rate > 1000000)
            throw std::invalid_argument("Invalid experimental pipeline configuration");
        for (float value : window)
            if (!std::isfinite(value)) throw std::invalid_argument("Nonfinite window");
    }
};

/// @brief Prepared octave bounds and frame-to-frame magnitude EMA.
/// @details Bounds reproduce OnTheFlyRFFT::smooth, including DC/Nyquist.
/// Only positive bins are needed: no positive smoothing interval reads a
/// negative-frequency bin. State is producer-owned, independent of UI reads.
class MagnitudeOutput {
    std::vector<size_t> low, high;
    std::vector<float> previous;
    float alpha;
    bool smoothing;
 public:
    explicit MagnitudeOutput(const Configuration& c) :
        low(c.n / 2 + 1), high(low.size()), previous(low.size(), 0.f), alpha(c.alpha), smoothing(c.octave > 0) {
        const float width = c.sample_rate / static_cast<float>(c.n);
        const float maximum = c.sample_rate / 2.f;
        const float half = std::pow(2.f, c.octave / 2.f);
        const float ratio = std::pow(2.f, c.octave);
        for (size_t k = 0; k < low.size(); ++k) {
            float a = k * width / half, b = k * width * half;
            if (b > maximum) { b = maximum; a = b / ratio; }
            low[k] = c.octave == 0 ? k : static_cast<size_t>(std::floor(a / width));
            high[k] = c.octave == 0 ? k : std::min(c.n - 1,
                static_cast<size_t>(std::floor(b / width)));
        }
    }
    /// @brief One smoothing/EMA/output unit, with a completed prefix array.
    void step(size_t k, const std::vector<float>& prefix,
              const std::vector<float>& magnitude, Spectrum& result) {
        const float value = smoothing
            ? (prefix[high[k] + 1] - prefix[low[k]])
                / static_cast<float>(high[k] - low[k] + 1)
            : magnitude[k];
        previous[k] = alpha * std::abs(previous[k]) + (1.f - alpha) * value;
        result.magnitude[k] = previous[k];
    }
};

/// @brief Initialize every mailbox slot before sharing it with threads.
inline void prepare_mailbox(DisplayMailbox<Spectrum>& mailbox, size_t bins) {
    for (size_t i = 0; i < 3; ++i) {
        mailbox.writable().magnitude.resize(bins);
        mailbox.publish();
        mailbox.consume();
    }
}

/// @brief Scheduling policies for the same dependency-ordered arithmetic.
enum class Schedule { Overlapped, StageBurst, Serial };

/// @brief A one-hop or four-hop analysis pipeline using balanced quotas.
/// @details process accepts one sample, starting at index zero. Frame j ends
/// at jH and publishes at jH+4H-1. Negative-time input is zero. A ring of N+H
/// values retains every frame until preparation completes. Four rotating
/// slots eliminate interstage copies. Each steady-state call executes at most
/// ceil(M/H)+ceil(B/H)+2*ceil((M+1)/H) units plus constant scheduling/input/
/// publication work, M=N/2, B=M/2*log2(M). Units have unequal time costs.
/// Serial instead spends ceil((M+B+2(M+1))/H) units at most per call on a
/// single frame's dependency chain; it publishes at jH+H-1 with one frame
/// slot. Equal operation counts do not make the unequal stage costs equal.
/// Input samples must be finite; nonfinite input is not sanitized here.
/// Configuration is immutable. Construct a new instance to reset/reconfigure,
/// outside processing and with both threads stopped. No hot-path allocation.
/// One producer calls process; one consumer uses mailbox.consume/current.
class Pipeline {
    /// A slot is prepared, transformed, reconstructed, then retired in order.
    struct Frame {
        std::vector<std::complex<float>> packed;
        std::vector<float> prefix, magnitude;
        size_t span = 2, group = 0, pair = 0;
        uint64_t end = 0;
        explicit Frame(size_t n) : packed(n / 2), prefix(n / 2 + 2, 0.f),
            magnitude(n / 2 + 1) {}
    };
    Configuration config;
    BitReversalTable reversal;
    TwiddleFactors<float> fft_twiddles, real_twiddles;
    std::vector<Frame> frames;
    std::vector<float> ring;
    MagnitudeOutput output;
    size_t head = 0, origin = 0, phase = 0, slot = 0, active = 0;
    size_t butterflies;
    uint64_t sample_index = 0;
    Schedule schedule;
    size_t serial_stage = 0, serial_cursor = 0;

    /// @brief Run one radix-2 butterfly, matching the production arithmetic.
    void butterfly(Frame& frame) {
        const size_t half = frame.span / 2;
        const auto w = fft_twiddles[frame.pair * (config.n / 2 / frame.span)];
        const auto even = frame.packed[frame.group + frame.pair];
        const auto odd = complex_multiply(frame.packed[frame.group + frame.pair + half], w);
        frame.packed[frame.group + frame.pair] = even + odd;
        frame.packed[frame.group + frame.pair + half] = even - odd;
        if (++frame.pair == half) {
            frame.pair = 0;
            frame.group += frame.span;
            if (frame.group == config.n / 2) { frame.group = 0; frame.span *= 2; }
        }
    }
    /// @brief Reconstruct one bin and append its magnitude to the prefix sum.
    void reconstruct(Frame& frame, size_t k) {
        const size_t m = config.n / 2;
        std::complex<float> value;
        if (k == 0 || k == m) {
            const auto z = frame.packed[0];
            value = {z.real() + (k == 0 ? z.imag() : -z.imag()), 0.f};
        } else {
            const auto a = frame.packed[k];
            const auto b = std::conj(frame.packed[m-k]);
            value = complex_multiply(real_twiddles[k], a - b);
            value = complex_multiply(value, j<float>());
            value = complex_multiply<float>(a + b - value, 0.5f);
        }
        frame.magnitude[k] = std::abs(value);
        frame.prefix[k+1] = frame.prefix[k] + frame.magnitude[k];
    }
    /// @brief Completed units after s calls. Bounded sizes prevent overflow.
    size_t progress(size_t work, size_t s) const {
        return schedule == Schedule::StageBurst
            ? (s == config.hop ? work : 0) : static_cast<uint64_t>(s) * work / config.hop;
    }

    /// @brief One bounded task in topological order; shared by all schedules.
    void unit(size_t stage, Frame& frame, size_t k) {
        switch (stage) {
        case 0:
            frame.packed[reversal[k]] = {
                ring[(origin + 2*k) % ring.size()] * config.window[2*k],
                ring[(origin + 2*k+1) % ring.size()] * config.window[2*k+1]};
            break;
        case 1: butterfly(frame); break;
        case 2: reconstruct(frame, k); break;
        case 3: output.step(k, frame.prefix, frame.magnitude, mailbox.writable()); break;
        }
    }

 public:
    DisplayMailbox<Spectrum> mailbox;
    /// Number of units actually run in each stage on the last call, for tests.
    std::array<size_t, 4> last_work{{0, 0, 0, 0}};

    /// @param policy Overlapped stages, matched stage bursts, or one-hop serial.
    explicit Pipeline(const Configuration& c, Schedule policy = Schedule::Overlapped) :
        config(c), reversal(c.n / 2), fft_twiddles(c.n / 2), real_twiddles(c.n),
        ring(c.n + c.hop, 0.f), output(c), butterflies(0), schedule(policy) {
        const size_t slots = policy == Schedule::Serial ? 1 : 4;
        frames.reserve(slots);
        for (size_t i = 0; i < slots; ++i) frames.emplace_back(c.n);
        for (size_t m = c.n / 2; m > 1; m /= 2) butterflies += c.n / 4;
        prepare_mailbox(mailbox, c.n / 2 + 1);
    }
    /// @brief Accept a sample and return true exactly when a frame publishes.
    bool process(float input) {
        ring[head] = input;
        if (phase == 0) {
            origin = (head + ring.size() + 1 - config.n) % ring.size();
            frames[slot].end = sample_index;
            frames[slot].span = 2;
            frames[slot].group = frames[slot].pair = 0;
            active = std::min(size_t(4), active + 1);
            serial_stage = serial_cursor = 0;
        }
        const std::array<size_t, 4> work{{config.n / 2, butterflies,
                                        config.n / 2 + 1, config.n / 2 + 1}};
        last_work = {{0, 0, 0, 0}};
        if (schedule == Schedule::Serial) {
            const size_t total = work[0] + work[1] + work[2] + work[3];
            const size_t quota = progress(total, phase + 1) - progress(total, phase);
            for (size_t i = 0; i < quota; ++i) {
                unit(serial_stage, frames[0], serial_cursor);
                ++last_work[serial_stage];
                if (++serial_cursor == work[serial_stage]) {
                    serial_cursor = 0;
                    ++serial_stage;
                }
            }
        } else {
            for (size_t stage = 0; stage < active; ++stage) {
                Frame& frame = frames[(slot + 4 - stage) % 4];
                const size_t begin = progress(work[stage], phase);
                const size_t end = progress(work[stage], phase + 1);
                last_work[stage] = end - begin;
                for (size_t k = begin; k < end; ++k) unit(stage, frame, k);
            }
        }
        bool published = false;
        if (++phase == config.hop) {
            if (active == 4 || schedule == Schedule::Serial) {
                mailbox.writable().frame_end = frames[schedule == Schedule::Serial
                    ? 0 : (slot + 1) % 4].end;
                mailbox.publish();
                published = true;
            }
            phase = 0;
            slot = (slot + 1) % frames.size();
        }
        head = (head + 1) % ring.size();
        ++sample_index;
        return published;
    }
};

}  // namespace Experiment
}  // namespace Fourier
#endif  // ARHYTHMETIC_UNITS_FOURIER_EXPERIMENTAL_PIPELINE_HPP_
