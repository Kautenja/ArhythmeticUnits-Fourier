#!/usr/bin/env python3
"""Run or verify the complete-pipeline experiment, preserving manuscript v1."""
import argparse
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
ARCHIVE = ROOT / 'whitepaper/data/pipeline'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def output(command):
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


def summarize(rows):
    result = []
    keys = sorted({(int(r['n']), int(r['hop']), float(r['octave']),
                    r['mode'], int(r['block'])) for r in rows})
    for n, hop, octave, mode, block in keys:
        selected = [r for r in rows if (int(r['n']), int(r['hop']), float(r['octave']),
                    r['mode'], int(r['block'])) == (n, hop, octave, mode, block)]
        assert sorted(int(r['repetition']) for r in selected) == list(range(12))
        entry = dict(n=n, hop=hop, octave=octave, mode=mode, block=block)
        for field in ['hop_ns', 'median_ns', 'p99_ns', 'max_ns']:
            values = [float(r[field]) for r in selected]
            entry[field] = dict(median=statistics.median(values), min=min(values), max=max(values))
        expected_age = (hop if mode in ['legacy', 'serial'] else 4*hop) - 1
        assert all(int(r['age_samples']) == expected_age for r in selected)
        assert all(int(r['observations']) == 64*hop // (block or hop) for r in selected)
        entry['age_samples'] = expected_age
        if mode in ['pipeline', 'serial']:
            for comparator in ['legacy', 'stage_burst']:
                reference = {int(r['repetition']): r for r in rows if
                    (int(r['n']), int(r['hop']), float(r['octave']), r['mode'], int(r['block']))
                    == (n, hop, octave, comparator, block)}
                for field in ['hop_ns', 'max_ns']:
                    ratios = [float(r[field]) / float(reference[int(r['repetition'])][field])
                              for r in selected]
                    entry[f'{field}_ratio_to_{comparator}'] = dict(
                        median=statistics.median(ratios), min=min(ratios), max=max(ratios))
        result.append(entry)
    return result


def check(directory):
    meta = json.loads((directory / 'metadata.json').read_text())
    for path, expected in meta['source_sha256'].items():
        assert digest(ROOT / path) == expected, path
    for path, expected in meta['data_sha256'].items():
        assert digest(directory / path) == expected, path
    rows = list(csv.DictReader((directory / 'timing.csv').open()))
    assert len(rows) == 2880
    assert summarize(rows) == json.loads((directory / 'summary.json').read_text())
    baseline = list(csv.DictReader((directory / 'baseline.csv').open()))
    assert len(baseline) == 27
    assert 'All tests passed' in (directory / 'verification.txt').read_text()
    print(f'Passed: source/data hashes, 2880 timing rows, 27 phase rows, summary, verification log ({directory})')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--cpu', default='unrecorded')
    parser.add_argument('--memory-gib', type=int)
    args = parser.parse_args()
    directory = (args.out or (ARCHIVE if args.check else ROOT / 'whitepaper/build/pipeline')).resolve()
    if args.check:
        check(directory)
        return
    directory.mkdir(parents=True, exist_ok=True)
    sources = sorted(HERE.glob('*.hpp')) + sorted(HERE.glob('*.cpp')) + [HERE / 'run.py']
    sources += sorted((ROOT / 'src/dsp').glob('*.hpp'))
    sources += [ROOT / 'src/rack_extensions/display_mailbox.hpp',
                ROOT / 'test/dsp/test_analysis_pipeline.cpp', ROOT / 'SConstruct']
    hashes = {str(p.relative_to(ROOT)): digest(p) for p in sources}
    compiler = os.environ.get('CXX', 'g++')
    flags = ['-std=c++11', '-O3', '-DNDEBUG', '-Wall', '-Wextra', '-pedantic', '-Isrc']
    metadata = dict(started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    git_head=output(['git', 'rev-parse', 'HEAD']),
                    git_status=output(['git', 'status', '--short']),
                    compiler=output([compiler, '--version']), platform=platform.platform(),
                    source_sha256=hashes, repetitions=12, baseline_repetitions=9, measured_frames=64,
                    warmup_hops=20, baseline_warmup_frames=16,
                    mode_order='Four modes rotated by repetition; each position occurs three times in twelve repetitions.',
                    scope='Single scalar analyzer. Exact cadence adapters; magnitude snapshots. No Rack, actual audio callbacks, UI mapping, external FFT, or concurrent timing consumer.')
    metadata['cpu'] = args.cpu
    metadata['memory_gib'] = args.memory_gib
    metadata['compile_commands'] = []
    for source in ['baseline', 'measure']:
        command = [compiler, *flags, str((HERE / (source + '.cpp')).relative_to(ROOT)),
                   '-o', str(directory / source)]
        subprocess.run(command, cwd=ROOT, check=True)
        metadata['compile_commands'].append(command)
    subprocess.run(['scons', 'build_test/dsp/test_analysis_pipeline'], cwd=ROOT, check=True)
    with (directory / 'verification.txt').open('w') as stream:
        subprocess.run([str(ROOT / 'build_test/dsp/test_analysis_pipeline')],
                       cwd=ROOT, stdout=stream, check=True)
    metadata['clock'] = json.loads(output([str(directory / 'measure'), 'clock']))
    for binary, filename in [('baseline', 'baseline.csv'), ('measure', 'timing.csv')]:
        print(f'Measuring {binary}...', flush=True)
        with (directory / filename).open('w') as stream:
            subprocess.run([str(directory / binary)], cwd=ROOT, stdout=stream, check=True)
    assert hashes == {str(p.relative_to(ROOT)): digest(p) for p in sources}
    rows = list(csv.DictReader((directory / 'timing.csv').open()))
    (directory / 'summary.json').write_text(json.dumps(summarize(rows), indent=2) + '\n')
    metadata['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    metadata['data_sha256'] = {name: digest(directory / name) for name in
                             ['baseline.csv', 'timing.csv', 'summary.json', 'verification.txt']}
    (directory / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
    check(directory)


if __name__ == '__main__':
    main()
